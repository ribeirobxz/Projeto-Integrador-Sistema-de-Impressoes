﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Model.Historic
{
    public class CompraPacote
    {

        public int Codigo { get; set; }
        public int CodigoCompra { get; set; }
        public int CodigoPacote { get; set; }
        public short Multiplicador { get; set; }
        public decimal PrecoPacote { get; set; }

        public CompraPacote() { }

        public CompraPacote(int codigo, int codigoCompra, int codigoPacote, short multiplicador, decimal precoPacote)
        {
            Codigo = codigo;
            CodigoCompra = codigoCompra;
            CodigoPacote = codigoPacote;
            Multiplicador = multiplicador;
            PrecoPacote = precoPacote;
        }
    }
}
